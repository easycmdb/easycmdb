date=$(date +%Y%m%d)
mkdir -p /usr/local/easyops/uc-upgrade/log/${date}
sh license-update.sh |tee -a /usr/local/easyops/uc-upgrade/log/${date}/update_license-$(date +%H%M%S).log
