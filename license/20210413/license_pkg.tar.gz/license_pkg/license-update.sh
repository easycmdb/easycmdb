#!/bin/bash
file_path=$(cd "$(dirname "$0")"; pwd)
backup_path=/tmp/license_backup
# 组件标准版本
detect_proxy_standard_version='1.2.2'
collector_proxy_standard_version='1.10.2'
collector_proxy_server_standard_version='1.2.2'
ens_sdk_rs_standard_version='1.3.2'
receiver_standard_version='3.7.6'
data_loader_standard_version='1.7.8'
# 获取证书过期时间
expires_date=`grep -w 'Expires' /usr/local/easyops/etc/easyops.lic |awk -F '=' '{print $2}'`
Expires_date=`date -d ${expires_date} +%Y%m%d`
echo "expires_date is ${Expires_date}"
today=`date +%Y%m%d`
echo "today is $today"
# 获取当前环境组件版本
black_list="easy_core\|php_license\|influx_proxy\|easyops_pkgbuild\|erlang\|ens_client_db\|ens_sdk_rs\|service_registration\|orientdb\|deploy_init_update\|python_linux\|influxdb\|redis-sentinel\|easyadmin\|deploy_init\|redis\|mysql\|elasticsearch\|rabbitmq\|nginx\|storm_supervisor\|ens_client\|ens_root\|storm_topology\|easy_framework\|jdk\|storm_nimbus\|zookeeper\|kafka\|mongodb"
detect_proxy_version=`grep -v '-' /usr/local/easyops/detect_proxy/version.ini`
collector_proxy_version=`grep -v '-' /usr/local/easyops/collector_proxy/version.ini`
collector_proxy_server_version=`grep -v '-' /usr/local/easyops/collector_proxy_server/version.ini`
ens_sdk_rs_version=`grep -v '-' /usr/local/easyops/ens_sdk_rs/version.ini`
receiver_version=`grep -v '-' /usr/local/easyops/receiver/version.ini`
data_loader_version=`grep -v '-' /usr/local/easyops/data_loader/version.ini`
echo "detect_proxy_version is ${detect_proxy_version}"
echo "collector_proxy_version is ${collector_proxy_version}"
echo "collector_proxy_server_version is ${collector_proxy_server_version}"
echo "ens_sdk_rs_version is ${ens_sdk_rs_version}"
echo "receiver_version is ${receiver_version}"
echo "data_loader_version is ${data_loader_version}"
# 创建备份路径
mkdir -p $backup_path

function version_ge() { test "$(echo "$@" | tr " " "\n" | sort -rV | head -n 1)" == "$1"; }

function restart_module() {
  echo "begin to restart"
  for file in `ls /usr/local/easyops |grep -v ${black_list}`
  do
    if [[ -d /usr/local/easyops/$file ]];then
      cd /usr/local/easyops/$file
      if [[ `easyops status |grep -c stopped` -le '0' ]];then
        easyops restart
        echo "$file restarted"
        else
        echo "$file stopped"
      fi
    fi
  done
  echo "restart finish"
}

function replace_file() {
  # 传入文件绝对路径
  echo "file to replace: $1"
  base_dir="/usr/local/easyops"
  modele_path_file=${1#*easyops/}
  file_name=${modele_path_file##*/}   #文件名
  module_name=${modele_path_file%%/*}   #模块名
  path=${modele_path_file%/*}      #  文件的相对路径
  #echo $module_name $path $file_name
  if [[ -d $base_dir/$module_name ]];then
    mkdir -p $backup_path/$path
    cp -f $1 $backup_path/$path/$file_name$(date +%Y%m%d%H%M%S)
    cp -f $file_path/$path/$file_name $1
    echo "replace finish"
  else
    echo "No such file or directory"
  fi
}

function check_link() {
  # 传入绝对路径
  echo "link to check: $1"
  base_dir="/usr/local/easyops"
  modele_path_file=${1#*easyops/}
  file_name=${modele_path_file##*/}   #文件名
  module_name=${modele_path_file%%/*}   #模块名
  path=${modele_path_file%/*}      #  文件的相对路径
  if [ -h $1 ];then
    echo "It is a link,nothing to do"
  else
    echo "It is a file,move it and make a link"
    mkdir -p $backup_path/$path
    mv -f $1 $backup_path/$path/$file_name
    ln -s /usr/local/easyops/ens_sdk_rs/libens_sdk.so $1
  fi
}
# 先判断证书有效期，如证书已经过期，则直接更新证书，不判断组件版本
if [[ ${Expires_date} > ${today} ]];then
  echo 'the lincese is valid'
  # 判断detect_proxy版本
  if version_ge ${detect_proxy_version} ${detect_proxy_standard_version} || [[ ! -n ${detect_proxy_version} ]];then
    if [[ ! -n ${detect_proxy_version} ]];then
      echo "detect_proxy is not installed"
    else
      echo "detect_proxy new enough"
    fi
    detect_proxy_check="true"
  else
    echo "detect_proxy version is not new enough"
  fi
  # 判断collector_proxy版本
  if version_ge ${collector_proxy_version} ${collector_proxy_standard_version} || [[ ! -n ${collector_proxy_version} ]];then
    if [[ ! -n ${collector_proxy_version} ]];then
      echo "collector_proxy is not installed"
    else
      echo "collector_proxy new enough"
    fi
    collector_proxy_check="true"
  else
    collector_proxy_standard_version="1.8.4"
    if version_ge ${collector_proxy_standard_version} ${collector_proxy_version};then
      echo "collector_proxy version is below 1.8.5,skip it"
      collector_proxy_check="false"
    else
      echo "collector_proxy version is not new enough"
    fi
  fi
  # 判断collector_proxy_server版本
  if version_ge ${collector_proxy_server_version} ${collector_proxy_server_standard_version} || [[ ! -n ${collector_proxy_server_version} ]];then
    if [[ ! -n ${collector_proxy_server_version} ]];then
      echo "collector_proxy_server is not installed"
    else
      echo "collector_proxy_server is new enough"
    fi
    collector_proxy_server_check="true"
  else
    collector_proxy_server_standard_version="1.0.2"
    if version_ge ${collector_proxy_server_standard_version} ${collector_proxy_server_version};then
      echo "collector_proxy_server version is below 1.0.3,skip it"
      collector_proxy_server_check="false"
    else
      echo "collector_proxy_server version is not new enough"
    fi
  fi
  else
    echo 'the license is expired, update license directly'
    lincese_check='fales'
fi
# 判断receiver版本
if version_ge ${receiver_version} ${receiver_standard_version} || [[ ! -n ${receiver_version} ]];then
  receiver_check="true"
  echo "no need to replace receiver"
fi
# 判断data_loader版本
if version_ge ${data_loader_version} ${data_loader_standard_version} || [[ ! -n ${data_loader_version} ]];then
  data_loader_check="true"
  echo "no need to replace data_loader"
fi



if [[ -n ${detect_proxy_check} ]] && [[ -n ${collector_proxy_check} ]] && [[ -n ${collector_proxy_server_check} ]] || [[ -n ${lincese_check} ]];then
   if version_ge ${ens_sdk_rs_standard_version} ${ens_sdk_rs_version} || [[ ! -n ${ens_sdk_rs_version} ]];then
   echo "ens_sdk_rs is too old, update it"
       if [[ -n ${ens_sdk_rs_version} ]];then
       cp -r /usr/local/easyops/ens_sdk_rs $backup_path/ens_sdk_rs$(date +%Y%m%d%H%M%S)
       rm -rf /usr/local/easyops/ens_sdk_rs
       fi
   mkdir /usr/local/easyops/ens_sdk_rs
   tar -xvf $file_path/ens_sdk_rs.gz -C /usr/local/easyops/ens_sdk_rs --strip-components 1
   # 检查链接
   check_link /usr/local/easyops/ens_client/sdk/libens_sdk.so
   check_link /usr/local/easyops/python/dependency/libens_sdk.so
   # 替换证书
   replace_file /usr/local/easyops/etc/easyops.lic
   # 替换二进制文件
   if [[ ! -n ${receiver_check} ]];then
       replace_file /usr/local/easyops/receiver/bin/receiver
   fi
   if [[ ! -n ${data_loader_check} ]];then
   replace_file /usr/local/easyops/data_loader/bin/data_loader
   fi
   # 重启组件
   restart_module
   else
   echo "ens_sdk_rs is new enough,update lincense"
   if [ `grep -c "Host-ID" /usr/local/easyops/etc/easyops.lic` -ne '0' ];then
      echo "old version license,need to restart module"
      replace_file /usr/local/easyops/etc/easyops.lic
      restart_module
      else
      echo "new version license,replace directly"
      replace_file /usr/local/easyops/etc/easyops.lic
      fi
   fi
else
echo "module is not new enough,please try again after update"
fi
